import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DORIA AI CLIPPER",
  description: "Crea clips verticales de gaming para Shorts y TikTok."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
