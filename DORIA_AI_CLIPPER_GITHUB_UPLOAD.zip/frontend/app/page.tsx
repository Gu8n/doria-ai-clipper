"use client";
import { useState } from "react";

const API = (process.env.NEXT_PUBLIC_WORKER_URL || "").replace(/\\/$/, "");

export default function Home() {
  const [video, setVideo] = useState<File | null>(null);
  const [start, setStart] = useState("0");
  const [duration, setDuration] = useState("30");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("Sube un video propio o autorizado para comenzar.");
  const [download, setDownload] = useState("");
  const [credits, setCredits] = useState(10);

  async function createClip(e: React.FormEvent) {
    e.preventDefault();
    setDownload("");
    if (!API) { setMessage("Falta configurar NEXT_PUBLIC_WORKER_URL en Vercel."); return; }
    if (!video) { setMessage("Primero selecciona un video."); return; }
    if (credits < 1) { setMessage("No tienes créditos demo disponibles."); return; }
    setBusy(true); setMessage("Procesando tu clip…");
    try {
      const form = new FormData();
      form.append("file", video);
      form.append("start_seconds", start);
      form.append("duration_seconds", duration);
      const res = await fetch(API + "/api/create-clip", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "No se pudo crear el clip.");
      setDownload(API + data.download_url);
      setCredits(v => v - 1);
      setMessage("¡Clip listo! Ya puedes descargarlo.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Ocurrió un error.");
    } finally { setBusy(false); }
  }

  return <main className="wrap">
    <div className="brand">DORIA AI</div>
    <span className="credit">Créditos demo: {credits}</span>
    <h1 className="hero">GAMING CLIPS.<br/><span className="accent">SIN COMPLICACIONES.</span></h1>
    <p className="sub">Convierte tus mejores jugadas en videos verticales listos para YouTube Shorts y TikTok. Elige el fragmento y descarga tu clip en formato 9:16.</p>
    <form className="panel" onSubmit={createClip}>
      <h2>Crear nuevo clip</h2>
      <label className="field">Video (MP4, MOV o WebM)</label>
      <input className="input" type="file" accept="video/*" onChange={e => setVideo(e.target.files?.[0] || null)} />
      <div className="grid">
        <div><label className="field">Inicio del clip (segundos)</label><input className="input" type="number" min="0" step="1" value={start} onChange={e => setStart(e.target.value)} /></div>
        <div><label className="field">Duración</label><select className="input" value={duration} onChange={e => setDuration(e.target.value)}><option value="30">30 segundos</option><option value="45">45 segundos</option><option value="60">60 segundos</option></select></div>
      </div>
      <p className="hint">El sistema adapta el video a vertical 9:16 y centra el encuadre. Próximamente: detección automática de jugadas destacadas.</p>
      <button className="btn" disabled={busy}>{busy ? "PROCESANDO…" : "GENERAR CLIP"}</button>
      <p className="status">{message}</p>
      {download && <a className="btn" style={{display:"block",textAlign:"center",textDecoration:"none"}} href={download}>DESCARGAR MI CLIP</a>}
    </form>
    <p className="hint" style={{marginTop:22}}>Importante: utiliza únicamente material propio o cuyo titular te haya autorizado a editar y publicar.</p>
  </main>;
}
