# DORIA AI CLIPPER

Aplicación web para crear clips verticales de gaming a partir de videos propios o autorizados.

## Estructura
- `frontend/`: interfaz Next.js para Vercel.
- `worker/`: API FastAPI + FFmpeg para procesar clips.

## Estado del MVP
Permite cargar un video, indicar el segundo de inicio y elegir 30, 45 o 60 segundos. El worker convierte el fragmento a formato vertical 9:16 y permite descargarlo.

La detección automática de momentos, inicio de sesión, créditos persistentes y pagos reales todavía no están implementados.

## Despliegue
1. Despliega `worker/` en Railway usando su Dockerfile.
2. En Vercel importa este repositorio y configura Root Directory como `frontend`.
3. Añade `NEXT_PUBLIC_WORKER_URL` con la URL pública de Railway, sin barra final.
4. Despliega el frontend.

Utiliza únicamente videos propios o para los que tengas autorización de edición y publicación.
