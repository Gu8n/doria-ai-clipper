import uuid, subprocess
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

app = FastAPI(title="DORIA AI CLIPPER Worker")
BASE = Path("/tmp/doria-clips")
BASE.mkdir(parents=True, exist_ok=True)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health():
    return {"status": "ok", "service": "DORIA AI CLIPPER"}

@app.get("/api/status")
def status():
    return {"status": "ready", "engine": "FFmpeg"}

@app.post("/api/create-clip")
async def create_clip(file: UploadFile = File(...), start_seconds: float = Form(0), duration_seconds: int = Form(30)):
    if not file.filename or not file.filename.lower().endswith((".mp4", ".mov", ".webm", ".mkv", ".m4v")):
        raise HTTPException(400, "Formato no compatible. Sube MP4, MOV o WebM.")
    if start_seconds < 0 or duration_seconds not in (30, 45, 60):
        raise HTTPException(400, "Inicio o duración no válidos.")
    job = uuid.uuid4().hex
    source, output = BASE / f"{job}_source", BASE / f"{job}.mp4"
    try:
        size = 0
        with source.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 1024 * 1024 * 1024:
                    raise HTTPException(413, "El video supera el límite de 1 GB.")
                out.write(chunk)
        cmd = ["ffmpeg", "-y", "-ss", str(start_seconds), "-i", str(source), "-t", str(duration_seconds),
               "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
               "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k",
               "-movflags", "+faststart", str(output)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        if result.returncode != 0 or not output.exists():
            raise HTTPException(422, "No se pudo procesar el video. Comprueba que el archivo sea válido.")
        return {"job_id": job, "download_url": f"/api/download/{job}"}
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "El procesamiento tardó demasiado.")
    finally:
        source.unlink(missing_ok=True)

@app.get("/api/download/{job_id}")
def download(job_id: str):
    if not job_id.isalnum():
        raise HTTPException(400, "ID no válido.")
    path = BASE / f"{job_id}.mp4"
    if not path.exists():
        raise HTTPException(404, "Clip no encontrado.")
    return FileResponse(path, media_type="video/mp4", filename="doria-clip.mp4")
